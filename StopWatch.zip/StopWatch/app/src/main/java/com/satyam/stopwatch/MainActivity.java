package com.satyam.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView timeTxt;
    boolean isRunning;
    long milliseconds = 0;
    Button startBtn, pauseBtn, restartBtn;
    Handler handler = new Handler();
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);
        pauseBtn = findViewById(R.id.pauseBtn);
        restartBtn = findViewById(R.id.restartBtn);
        timeTxt = findViewById(R.id.timeTxt);

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isRunning) {
                    isRunning = true;

                    start();
                }
            }
        });

        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pause();
            }
        });

        restartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });
    }

    private void start() {

            runnable = new Runnable() {
                @Override
                public void run() {
                    milliseconds += 10;
                    updateTimerText();
                    handler.postDelayed(this, 10);
                }
            };
if (isRunning){
    handler.post(runnable);

}
        }

    private void pause() {
        if (isRunning) {
            handler.removeCallbacks(runnable);
            isRunning = false;
            pauseBtn.setText("RESUME");
        }else {
            isRunning=true;
            start();
            pauseBtn.setText("PAUSE");

        }
    }

    private void reset() {
        handler.removeCallbacks(runnable);
        isRunning = false;

        milliseconds = 0;
        updateTimerText();
    }

    private void updateTimerText() {
        int hours = (int) (milliseconds / 3600000);
        int minutes = (int) ((milliseconds % 3600000) / 60000);
        int seconds = (int) ((milliseconds % 60000) / 1000);
        int millisecondsValue = (int) (milliseconds % 1000);

        String time = String.format(Locale.getDefault(), "%02d:%02d:%02d:%03d", hours, minutes, seconds, millisecondsValue);
        timeTxt.setText(time);
    }



}
